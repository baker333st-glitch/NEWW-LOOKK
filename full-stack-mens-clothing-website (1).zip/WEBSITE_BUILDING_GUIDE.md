# 🛍️ NEW LOOK FASHION Website - Complete Building Guide

## Step-by-Step Process to Create This E-Commerce Website

---

## 📋 TABLE OF CONTENTS

1. [Prerequisites & Tools Required](#1-prerequisites--tools-required)
2. [Project Setup](#2-project-setup)
3. [Database Design](#3-database-design)
4. [Frontend Development](#4-frontend-development)
5. [Backend API Development](#5-backend-api-development)
6. [Admin Panel Creation](#6-admin-panel-creation)
7. [Styling & Animations](#7-styling--animations)
8. [Testing](#8-testing)
9. [Deployment](#9-deployment)
10. [Maintenance](#10-maintenance)

---

## 1. Prerequisites & Tools Required

### 💻 Software to Install on Your Computer

| Software | Purpose | Download Link |
|----------|---------|---------------|
| **Node.js** (v18+) | JavaScript runtime | https://nodejs.org |
| **VS Code** | Code editor | https://code.visualstudio.com |
| **Git** | Version control | https://git-scm.com |
| **PostgreSQL** | Database | https://postgresql.org/download |

### 📚 Knowledge Required

- Basic HTML, CSS, JavaScript
- React.js basics
- Understanding of REST APIs
- Basic SQL knowledge

### 🛠️ Technologies Used in This Project

```
Frontend:
├── Next.js 16 (React Framework)
├── React 19
├── Tailwind CSS 4 (Styling)
└── TypeScript (Type Safety)

Backend:
├── Next.js API Routes
├── Drizzle ORM (Database)
├── PostgreSQL (Database)
└── bcryptjs (Password Hashing)
```

---

## 2. Project Setup

### Step 2.1: Create New Project

Open Terminal/Command Prompt and run:

```bash
# Create new Next.js project
npx create-next-app@latest newlookfz

# Answer the prompts:
# ✔ Would you like to use TypeScript? Yes
# ✔ Would you like to use ESLint? Yes
# ✔ Would you like to use Tailwind CSS? Yes
# ✔ Would you like to use `src/` directory? Yes
# ✔ Would you like to use App Router? Yes
# ✔ Would you like to customize the default import alias? No
```

### Step 2.2: Navigate to Project

```bash
cd newlookfz
```

### Step 2.3: Install Required Packages

```bash
# Database packages
npm install drizzle-orm pg dotenv

# Development packages
npm install -D drizzle-kit @types/pg

# Authentication packages
npm install bcryptjs uuid
npm install -D @types/bcryptjs @types/uuid
```

### Step 2.4: Create Project Structure

```
newlookfz/
├── src/
│   ├── app/
│   │   ├── page.tsx          # Home page
│   │   ├── layout.tsx        # Main layout
│   │   ├── globals.css       # Global styles
│   │   ├── admin/
│   │   │   └── page.tsx      # Admin panel
│   │   └── api/
│   │       ├── auth/
│   │       │   ├── login/route.ts
│   │       │   └── otp/route.ts
│   │       ├── products/
│   │       │   ├── route.ts
│   │       │   └── [id]/route.ts
│   │       ├── upload/route.ts
│   │       └── download/route.ts
│   ├── components/
│   │   ├── Logo.tsx
│   │   ├── MarqueeText.tsx
│   │   └── ProductCard.tsx
│   ├── db/
│   │   ├── index.ts          # Database connection
│   │   └── schema.ts         # Database tables
│   └── lib/
│       └── auth.ts           # Authentication helpers
├── public/
│   └── uploads/              # Uploaded images
├── .env                      # Environment variables
├── drizzle.config.json       # Drizzle configuration
└── package.json
```

### Step 2.5: Create Environment File

Create `.env` file in root:

```env
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/newlookfz_db
```

### Step 2.6: Create Drizzle Config

Create `drizzle.config.json`:

```json
{
  "schema": "./src/db/schema.ts",
  "out": "./drizzle",
  "dialect": "postgresql",
  "dbCredentials": {
    "url": "postgresql://postgres:your_password@localhost:5432/newlookfz_db"
  }
}
```

---

## 3. Database Design

### Step 3.1: Understand Database Structure

```
DATABASE: newlookfz_db
│
├── TABLE: admins
│   ├── id (Primary Key)
│   ├── phone (Unique)
│   ├── password_hash
│   └── created_at
│
├── TABLE: products
│   ├── id (Primary Key)
│   ├── name
│   ├── description
│   ├── image_url
│   ├── price
│   ├── discount_price
│   ├── sizes
│   ├── category
│   ├── in_stock
│   ├── article_code
│   ├── created_at
│   └── updated_at
│
├── TABLE: otp_codes
│   ├── id (Primary Key)
│   ├── phone
│   ├── code
│   ├── expires_at
│   ├── used
│   └── created_at
│
└── TABLE: download_requests
    ├── id (Primary Key)
    ├── contact_number
    ├── email
    ├── verified
    └── created_at
```

### Step 3.2: Create Database Connection

Create `src/db/index.ts`:

```typescript
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export const db = drizzle(pool);
```

### Step 3.3: Create Schema

Create `src/db/schema.ts`:

```typescript
import { pgTable, serial, text, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";

// Admins table for login
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  phone: varchar("phone", { length: 15 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Products table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  price: integer("price").notNull(),
  discountPrice: integer("discount_price"),
  sizes: text("sizes").notNull().default("S,M,L,XL,XXL"),
  category: varchar("category", { length: 100 }).default("General"),
  inStock: boolean("in_stock").notNull().default(true),
  articleCode: varchar("article_code", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// OTP codes for verification
export const otpCodes = pgTable("otp_codes", {
  id: serial("id").primaryKey(),
  phone: varchar("phone", { length: 15 }).notNull(),
  code: varchar("code", { length: 6 }).notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Download requests
export const downloadRequests = pgTable("download_requests", {
  id: serial("id").primaryKey(),
  contactNumber: varchar("contact_number", { length: 15 }).notNull(),
  email: text("email").notNull(),
  verified: boolean("verified").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
```

### Step 3.4: Push Schema to Database

```bash
# Create database first (in PostgreSQL)
# psql -U postgres
# CREATE DATABASE newlookfz_db;

# Push schema
npx drizzle-kit push
```

---

## 4. Frontend Development

### Step 4.1: Create Layout (src/app/layout.tsx)

```typescript
import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NEW LOOK FASHION | Premium Menswear Store",
  description: "Premium menswear clothing shop in Gorakhpur",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-black text-white">{children}</body>
    </html>
  );
}
```

### Step 4.2: Create Components

#### Logo Component (src/components/Logo.tsx)
```typescript
export default function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="bg-sky-500 rounded-lg p-2">
        <span className="text-4xl font-black text-white">FZ</span>
      </div>
      <div>
        <span className="text-lg font-bold text-sky-500">NEW LOOK</span>
        <span className="text-xs text-sky-300">FASHION</span>
      </div>
    </div>
  );
}
```

#### Marquee Component (src/components/MarqueeText.tsx)
```typescript
export default function MarqueeText() {
  return (
    <div className="overflow-hidden bg-sky-600 py-3">
      <div className="animate-marquee whitespace-nowrap">
        <span className="mx-8 text-xl font-bold">
          🔥 NEW LOOK FASHION — Premium Menswear 🔥
        </span>
        <span className="mx-8 text-xl font-bold text-yellow-300">
          ✨ Wholesale Available ✨
        </span>
      </div>
    </div>
  );
}
```

#### Product Card Component (src/components/ProductCard.tsx)
```typescript
export default function ProductCard({ product }) {
  const discount = product.discountPrice
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;

  const whatsappLink = `https://wa.me/916394038329?text=I want ${product.name}`;

  return (
    <div className="bg-gray-900 rounded-xl overflow-hidden">
      {/* Image */}
      <div className="aspect-square bg-gray-800">
        {product.imageUrl && (
          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
        )}
        {!product.inStock && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="bg-red-600 text-white px-4 py-2 rounded">OUT OF STOCK</span>
          </div>
        )}
        {discount > 0 && (
          <div className="absolute top-2 left-2 bg-red-600 text-white px-2 py-1 rounded">
            {discount}% OFF
          </div>
        )}
      </div>

      {/* Details */}
      <div className="p-4">
        <h3 className="text-white font-semibold">{product.name}</h3>
        <p className="text-sky-500 text-xs">Article: {product.articleCode}</p>

        {/* Price */}
        <div className="flex items-center gap-2 mt-2">
          {product.discountPrice ? (
            <>
              <span className="text-sky-500 font-bold text-xl">₹{product.discountPrice}</span>
              <span className="text-gray-500 line-through">₹{product.price}</span>
            </>
          ) : (
            <span className="text-sky-500 font-bold text-xl">₹{product.price}</span>
          )}
        </div>

        {/* Sizes */}
        <div className="flex gap-1 mt-2">
          {product.sizes.split(",").map((size) => (
            <span key={size} className="bg-gray-800 text-gray-300 px-2 py-0.5 rounded text-xs">
              {size}
            </span>
          ))}
        </div>

        {/* Order Button */}
        <a
          href={whatsappLink}
          target="_blank"
          className="mt-3 block bg-green-600 text-white text-center py-2 rounded-lg font-semibold"
        >
          Order on WhatsApp
        </a>
      </div>
    </div>
  );
}
```

### Step 4.3: Create Home Page (src/app/page.tsx)

```typescript
"use client";

import { useState, useEffect } from "react";
import Logo from "@/components/Logo";
import MarqueeText from "@/components/MarqueeText";
import ProductCard from "@/components/ProductCard";

export default function HomePage() {
  const [products, setProducts] = useState([]);
  const [sortOrder, setSortOrder] = useState("default");

  useEffect(() => {
    fetch("/api/products")
      .then((res) => res.json())
      .then((data) => setProducts(data));
  }, []);

  // Sort products
  let sorted = [...products];
  if (sortOrder === "low") {
    sorted.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
  } else if (sortOrder === "high") {
    sorted.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Navbar */}
      <nav className="bg-black border-b border-sky-500/20 p-4">
        <Logo />
      </nav>

      {/* Marquee */}
      <MarqueeText />

      {/* Hero Section */}
      <section className="min-h-[60vh] flex items-center justify-center bg-gradient-to-b from-sky-900/20 to-black">
        <div className="text-center">
          <div className="bg-sky-500 rounded-2xl p-6 inline-block mb-6">
            <span className="text-7xl font-black text-white">FZ</span>
          </div>
          <h1 className="text-6xl font-black text-white">
            NEW LOOK <span className="text-sky-500">FASHION</span>
          </h1>
          <p className="text-sky-300 text-xl mt-2">Premium Menswear Collection</p>
        </div>
      </section>

      {/* Products */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-white mb-6">Our Collection</h2>

        {/* Filter */}
        <select
          value={sortOrder}
          onChange={(e) => setSortOrder(e.target.value)}
          className="bg-gray-900 text-white border border-gray-700 rounded-lg px-4 py-2 mb-6"
        >
          <option value="default">Sort: Default</option>
          <option value="low">Price: Low to High</option>
          <option value="high">Price: High to Low</option>
        </select>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {sorted.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Branches */}
      <section className="bg-gray-950 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-white text-center mb-8">Our 3 Branches</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-sky-500/10 border-2 border-sky-500 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white">Main Branch</h3>
              <p className="text-sky-300">Bichhiya, Gorakhpur</p>
              <p className="text-gray-400 text-sm">Near KMG Vatika School</p>
            </div>
            <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white">Branch 2</h3>
              <p className="text-sky-300">Neena Thapa, Gorakhpur</p>
            </div>
            <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white">Branch 3</h3>
              <p className="text-sky-300">Jhumila Bazar, Badhahalganj</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 border-t border-gray-800 py-8 text-center">
        <p className="text-gray-400">© 2024 NEW LOOK FASHION (newlookfz)</p>
        <p className="text-sky-500 mt-2">📞 6384038329 | WhatsApp: 6394038329</p>
      </footer>
    </div>
  );
}
```

---

## 5. Backend API Development

### Step 5.1: Create Authentication Helper (src/lib/auth.ts)

```typescript
import { db } from "@/db";
import { admins } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

const ADMIN_PHONE = "6394038329";

export async function ensureAdminExists() {
  const existing = await db.select().from(admins).where(eq(admins.phone, ADMIN_PHONE));
  if (existing.length === 0) {
    const hash = await bcrypt.hash("6394038329", 10);
    await db.insert(admins).values({
      phone: ADMIN_PHONE,
      passwordHash: hash,
    });
  }
}

export async function verifyAdmin(phone: string, password: string): Promise<boolean> {
  await ensureAdminExists();
  const admin = await db.select().from(admins).where(eq(admins.phone, phone));
  if (admin.length === 0) return false;
  return bcrypt.compare(password, admin[0].passwordHash);
}

export function generateToken(phone: string): string {
  const payload = JSON.stringify({ phone, ts: Date.now() });
  return Buffer.from(payload).toString("base64");
}

export function verifyToken(token: string): boolean {
  try {
    const payload = JSON.parse(Buffer.from(token, "base64").toString());
    return payload.phone === ADMIN_PHONE && Date.now() - payload.ts < 86400000;
  } catch {
    return false;
  }
}
```

### Step 5.2: Create Login API (src/app/api/auth/login/route.ts)

```typescript
import { NextRequest, NextResponse } from "next/server";
import { verifyAdmin, generateToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const { phone, password } = await req.json();

  if (!phone || !password) {
    return NextResponse.json({ error: "Phone and password required" }, { status: 400 });
  }

  const valid = await verifyAdmin(phone, password);
  if (!valid) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  const token = generateToken(phone);
  return NextResponse.json({ token, message: "Login successful" });
}
```

### Step 5.3: Create Products API (src/app/api/products/route.ts)

```typescript
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { verifyToken } from "@/lib/auth";
import { desc } from "drizzle-orm";

// GET all products (public)
export async function GET() {
  const all = await db.select().from(products).orderBy(desc(products.createdAt));
  return NextResponse.json(all);
}

// POST new product (admin only)
export async function POST(req: NextRequest) {
  const token = req.headers.get("Authorization")?.replace("Bearer ", "");
  if (!token || !verifyToken(token)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const result = await db.insert(products).values({
    name: body.name,
    description: body.description || "",
    imageUrl: body.imageUrl || "",
    price: Math.round(Number(body.price)),
    discountPrice: body.discountPrice ? Math.round(Number(body.discountPrice)) : null,
    sizes: body.sizes || "S,M,L,XL,XXL",
    category: body.category || "General",
    inStock: body.inStock !== false,
    articleCode: body.articleCode || null,
  }).returning();

  return NextResponse.json(result[0], { status: 201 });
}
```

### Step 5.4: Create Single Product API (src/app/api/products/[id]/route.ts)

```typescript
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

// GET single product
export async function GET(req: NextRequest, { params }) {
  const { id } = await params;
  const product = await db.select().from(products).where(eq(products.id, parseInt(id)));
  if (product.length === 0) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json(product[0]);
}

// UPDATE product
export async function PUT(req: NextRequest, { params }) {
  const token = req.headers.get("Authorization")?.replace("Bearer ", "");
  if (!token || !verifyToken(token)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const body = await req.json();

  const result = await db
    .update(products)
    .set({ ...body, updatedAt: new Date() })
    .where(eq(products.id, parseInt(id)))
    .returning();

  return NextResponse.json(result[0]);
}

// DELETE product
export async function DELETE(req: NextRequest, { params }) {
  const token = req.headers.get("Authorization")?.replace("Bearer ", "");
  if (!token || !verifyToken(token)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  await db.delete(products).where(eq(products.id, parseInt(id)));
  return NextResponse.json({ message: "Deleted" });
}
```

### Step 5.5: Create Upload API (src/app/api/upload/route.ts)

```typescript
import { NextRequest, NextResponse } from "next/server";
import { verifyToken } from "@/lib/auth";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { v4 as uuidv4 } from "uuid";

export async function POST(req: NextRequest) {
  const token = req.headers.get("Authorization")?.replace("Bearer ", "");
  if (!token || !verifyToken(token)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const formData = await req.formData();
  const file = formData.get("file") as File;

  if (!file) {
    return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
  }

  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);
  const ext = file.name.split(".").pop() || "jpg";
  const fileName = `${uuidv4()}.${ext}`;

  const uploadDir = join(process.cwd(), "public", "uploads");
  await mkdir(uploadDir, { recursive: true });
  await writeFile(join(uploadDir, fileName), buffer);

  return NextResponse.json({ url: `/uploads/${fileName}` });
}
```

---

## 6. Admin Panel Creation

### Step 6.1: Create Admin Page (src/app/admin/page.tsx)

The admin page includes:
- Login form with phone + password
- OTP verification (10 seconds validity)
- Product management dashboard
- Add/Edit/Delete products
- Toggle stock status
- Image upload

See the full code in `src/app/admin/page.tsx` in the project.

### Step 6.2: Admin Features Summary

```
ADMIN PANEL FEATURES:
├── Login System
│   ├── Phone: 6394038329
│   ├── Password: 6394038329
│   └── OTP: 10 seconds validity (strict)
│
├── Dashboard
│   ├── Total Products count
│   ├── In Stock count
│   ├── Out of Stock count
│   └── On Discount count
│
├── Product Management
│   ├── Add New Product
│   │   ├── Name
│   │   ├── Article Code
│   │   ├── Description
│   │   ├── Image (URL or Upload)
│   │   ├── Price & Discount Price
│   │   ├── Sizes (S,M,L,XL,XXL)
│   │   ├── Category
│   │   └── Stock Status
│   ├── Edit Product
│   ├── Delete Product
│   └── Toggle Stock (In/Out)
│
└── Logout
```

---

## 7. Styling & Animations

### Step 7.1: Global Styles (src/app/globals.css)

```css
@import "tailwindcss";

/* Custom Colors */
@theme {
  --color-skyblue: #0ea5e9;
  --color-skyblue-light: #7dd3fc;
  --color-skyblue-dark: #0369a1;
}

/* Marquee Animation */
@keyframes marquee {
  0% { transform: translateX(100%); }
  100% { transform: translateX(-100%); }
}

.animate-marquee {
  animation: marquee 15s linear infinite;
}

/* Fade In Up Animation */
@keyframes fadeInUp {
  0% { opacity: 0; transform: translateY(30px); }
  100% { opacity: 1; transform: translateY(0); }
}

.animate-fade-in-up {
  animation: fadeInUp 0.6s ease-out forwards;
}

/* Pulse Glow Animation */
@keyframes pulse-glow {
  0%, 100% { box-shadow: 0 0 5px rgba(14,165,233,0.4); }
  50% { box-shadow: 0 0 20px rgba(14,165,233,0.8); }
}

.animate-pulse-glow {
  animation: pulse-glow 2s ease-in-out infinite;
}

/* Float Animation */
@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
}

.animate-float {
  animation: float 3s ease-in-out infinite;
}

/* Product Image Zoom */
.product-card:hover .product-image {
  transform: scale(1.05);
}

.product-image {
  transition: transform 0.3s ease;
}

/* Custom Scrollbar */
::-webkit-scrollbar { width: 8px; }
::-webkit-scrollbar-track { background: #1e293b; }
::-webkit-scrollbar-thumb { background: #0ea5e9; border-radius: 4px; }
```

---

## 8. Testing

### Step 8.1: Run Development Server

```bash
npm run dev
```

Visit: http://localhost:3000

### Step 8.2: Test Checklist

```
✅ Home Page
   [ ] Logo displays correctly
   [ ] Marquee animation runs smoothly
   [ ] Products load from database
   [ ] Price filter works (low to high, high to low)
   [ ] Category filter works
   [ ] Stock filter works
   [ ] WhatsApp order button opens chat
   [ ] Image zoom works on click
   [ ] Mobile responsive

✅ Admin Panel (/admin)
   [ ] Login with phone: 6394038329, password: 6394038329
   [ ] OTP appears and expires in 10 seconds
   [ ] Add new product works
   [ ] Upload image works
   [ ] Edit product works
   [ ] Delete product works
   [ ] Toggle stock status works
   [ ] Logout works

✅ API Endpoints
   [ ] GET /api/products - returns all products
   [ ] POST /api/products - adds product (with token)
   [ ] PUT /api/products/[id] - updates product (with token)
   [ ] DELETE /api/products/[id] - deletes product (with token)
```

### Step 8.3: Build for Production

```bash
npm run build
```

Fix any errors that appear.

---

## 9. Deployment

### Option A: Deploy to Vercel (Recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Set environment variables in Vercel dashboard
# DATABASE_URL = your_production_database_url
```

### Option B: Deploy to Railway

1. Create account at railway.app
2. Create new project
3. Add PostgreSQL database
4. Connect GitHub repository
5. Set environment variables
6. Deploy

### Option C: Deploy to VPS (DigitalOcean, AWS, etc.)

```bash
# On server:
# 1. Install Node.js
# 2. Install PostgreSQL
# 3. Clone repository
git clone https://github.com/your-repo/newlookfz.git
cd newlookfz

# 4. Install dependencies
npm install

# 5. Set environment variables
export DATABASE_URL="postgresql://..."

# 6. Build
npm run build

# 7. Run with PM2
npm install -g pm2
pm2 start npm --name "newlookfz" -- start

# 8. Setup Nginx reverse proxy
# 9. Setup SSL with Let's Encrypt
```

### Database Hosting Options

| Provider | Free Tier | Best For |
|----------|-----------|----------|
| Neon | 0.5GB | Small projects |
| Supabase | 500MB | Small-Medium |
| Railway | 1GB | Medium projects |
| PlanetScale | 5GB | Large projects |

---

## 10. Maintenance

### Regular Tasks

```
DAILY:
- Check orders on WhatsApp
- Update stock status for sold items

WEEKLY:
- Add new products
- Update prices/discounts
- Check website performance

MONTHLY:
- Backup database
- Review analytics
- Update content

AS NEEDED:
- Fix bugs
- Add new features
- Update dependencies
```

### Backup Database

```bash
# Export database
pg_dump -U postgres newlookfz_db > backup_$(date +%Y%m%d).sql

# Import database
psql -U postgres newlookfz_db < backup_20240101.sql
```

### Update Dependencies

```bash
# Check for updates
npm outdated

# Update packages
npm update

# Update major versions (careful!)
npx npm-check-updates -u
npm install
```

---

## 📱 Contact & Support

**Shop**: NEW LOOK FASHION  
**Website**: newlookfz  
**Phone**: 6384038329  
**WhatsApp**: 6394038329  

**Branches**:
1. Bichhiya, Gorakhpur (Main - Near KMG Vatika School)
2. Neena Thapa, Gorakhpur
3. Jhumila Bazar, Badhahalganj

---

## 🎉 Congratulations!

You've now learned how to build a complete e-commerce website with:
- ✅ Frontend with React/Next.js
- ✅ Backend APIs
- ✅ PostgreSQL Database
- ✅ Admin Panel
- ✅ Image Upload
- ✅ Authentication with OTP
- ✅ Product Management
- ✅ Filtering & Sorting
- ✅ WhatsApp Integration
- ✅ Responsive Design
- ✅ Animations

**Total Time to Build**: 4-8 hours (for beginners)

**Cost**: ₹0 (using free tiers) to ₹500/month (production hosting)

---

*Guide created for NEW LOOK FASHION (newlookfz) website*
