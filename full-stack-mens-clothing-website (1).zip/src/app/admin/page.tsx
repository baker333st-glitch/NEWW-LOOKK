"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import Logo from "@/components/Logo";

interface Product {
  id: number;
  name: string;
  description: string | null;
  imageUrl: string | null;
  price: number;
  discountPrice: number | null;
  sizes: string;
  category: string | null;
  inStock: boolean;
  articleCode: string | null;
}

export default function AdminPage() {
  const [token, setToken] = useState<string | null>(null);
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState("");
  const [otpTimer, setOtpTimer] = useState(0);
  const [loginError, setLoginError] = useState("");
  const [loginStep, setLoginStep] = useState<"credentials" | "otp">("credentials");

  const [products, setProducts] = useState<Product[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    imageUrl: "",
    price: "",
    discountPrice: "",
    sizes: "S,M,L,XL,XXL",
    category: "General",
    inStock: true,
    articleCode: "",
  });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const saved = typeof window !== "undefined" ? localStorage.getItem("admin_token") : null;
    if (saved) setToken(saved);
  }, []);

  useEffect(() => {
    if (otpTimer > 0) {
      const interval = setInterval(() => setOtpTimer((t) => t - 1), 1000);
      return () => clearInterval(interval);
    }
    if (otpTimer === 0 && otpSent) {
      setOtpSent(false);
      setOtpCode("");
    }
  }, [otpTimer, otpSent]);

  const fetchProducts = useCallback(async () => {
    try {
      const res = await fetch("/api/products");
      const data = await res.json();
      setProducts(Array.isArray(data) ? data : []);
    } catch {
      setProducts([]);
    }
  }, []);

  useEffect(() => {
    if (token) fetchProducts();
  }, [token, fetchProducts]);

  const handleLogin = async () => {
    setLoginError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || "Login failed");
        return;
      }
      // Send OTP
      setLoginStep("otp");
      await sendOtp();
    } catch {
      setLoginError("Connection error");
    }
  };

  const sendOtp = async () => {
    try {
      const res = await fetch("/api/auth/otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, action: "send" }),
      });
      const data = await res.json();
      if (res.ok) {
        setOtpCode(data.otp);
        setOtpSent(true);
        setOtpTimer(10);
      }
    } catch {
      setLoginError("Failed to send OTP");
    }
  };

  const verifyOtp = async () => {
    if (otp !== otpCode) {
      setLoginError("Invalid OTP");
      return;
    }
    if (otpTimer <= 0) {
      setLoginError("OTP expired. Please try again.");
      return;
    }
    // Generate token
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, password }),
      });
      const data = await res.json();
      if (res.ok) {
        setToken(data.token);
        localStorage.setItem("admin_token", data.token);
      }
    } catch {
      setLoginError("Verification failed");
    }
  };

  const handleLogout = () => {
    setToken(null);
    localStorage.removeItem("admin_token");
    setLoginStep("credentials");
    setPhone("");
    setPassword("");
    setOtp("");
    setOtpSent(false);
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !token) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: fd,
      });
      const data = await res.json();
      if (res.ok) {
        setFormData((prev) => ({ ...prev, imageUrl: data.url }));
      }
    } catch {
      alert("Upload failed");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.price) {
      alert("Name and price are required");
      return;
    }
    setSaving(true);
    try {
      const url = editingProduct ? `/api/products/${editingProduct.id}` : "/api/products";
      const method = editingProduct ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...formData,
          price: parseInt(formData.price),
          discountPrice: formData.discountPrice ? parseInt(formData.discountPrice) : null,
        }),
      });
      if (res.ok) {
        resetForm();
        fetchProducts();
      }
    } catch {
      alert("Save failed");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this product?")) return;
    try {
      await fetch(`/api/products/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchProducts();
    } catch {
      alert("Delete failed");
    }
  };

  const handleToggleStock = async (product: Product) => {
    try {
      await fetch(`/api/products/${product.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ inStock: !product.inStock }),
      });
      fetchProducts();
    } catch {
      alert("Update failed");
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description || "",
      imageUrl: product.imageUrl || "",
      price: product.price.toString(),
      discountPrice: product.discountPrice?.toString() || "",
      sizes: product.sizes,
      category: product.category || "General",
      inStock: product.inStock,
      articleCode: product.articleCode || "",
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingProduct(null);
    setFormData({
      name: "",
      description: "",
      imageUrl: "",
      price: "",
      discountPrice: "",
      sizes: "S,M,L,XL,XXL",
      category: "General",
      inStock: true,
      articleCode: "",
    });
  };

  // Login Page
  if (!token) {
    return (
      <div
        className="min-h-screen flex items-center justify-center p-4"
        style={{
          background: "linear-gradient(135deg, #000 0%, #0c4a6e 50%, #000 100%)",
        }}
      >
        <div className="bg-gray-900 border border-skyblue/30 rounded-2xl p-8 max-w-sm w-full">
          <div className="flex justify-center mb-6">
            <Logo size="text-3xl" />
          </div>
          <h2 className="text-xl font-bold text-white text-center mb-6">🔐 Admin Login</h2>
          <p className="text-gray-400 text-xs text-center mb-4">Strict security: OTP valid for 10 seconds only</p>

          {loginStep === "credentials" ? (
            <div className="space-y-4">
              <input
                type="tel"
                placeholder="Phone Number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-skyblue outline-none"
              />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:border-skyblue outline-none"
              />
              <button
                onClick={handleLogin}
                className="w-full bg-skyblue hover:bg-skyblue-dark text-white py-3 rounded-lg font-bold transition-colors"
              >
                Login
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-skyblue/10 rounded-lg p-3 text-center">
                <p className="text-skyblue text-sm">OTP sent to your phone</p>
                <p className="text-yellow-400 text-xs mt-1">
                  {otpTimer > 0 ? `⏰ Expires in ${otpTimer}s` : "⚠️ OTP Expired"}
                </p>
                {otpCode && (
                  <p className="text-skyblue-light text-lg font-mono font-bold mt-2">
                    Demo OTP: {otpCode}
                  </p>
                )}
              </div>
              <input
                type="text"
                placeholder="Enter 6-digit OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                maxLength={6}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-center text-xl tracking-widest placeholder-gray-500 focus:border-skyblue outline-none"
              />
              <button
                onClick={verifyOtp}
                disabled={otpTimer <= 0}
                className="w-full bg-skyblue hover:bg-skyblue-dark disabled:bg-gray-700 disabled:text-gray-500 text-white py-3 rounded-lg font-bold transition-colors"
              >
                Verify OTP
              </button>
              <button
                onClick={() => setLoginStep("credentials")}
                className="w-full text-gray-400 hover:text-white text-sm transition-colors"
              >
                ← Back to Login
              </button>
            </div>
          )}

          {loginError && (
            <p className="text-red-400 text-sm text-center mt-3">{loginError}</p>
          )}
          <div className="mt-6 text-center">
            <a href="/" className="text-gray-500 hover:text-skyblue text-sm transition-colors">
              ← Back to Store
            </a>
          </div>
        </div>
      </div>
    );
  }

  // Admin Dashboard
  return (
    <div className="min-h-screen bg-black">
      {/* Admin Navbar */}
      <nav className="sticky top-0 z-40 bg-gray-950/90 backdrop-blur-md border-b border-skyblue/20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo size="text-xl" />
            <span className="text-skyblue text-sm font-semibold bg-skyblue/10 px-2 py-1 rounded">ADMIN</span>
          </div>
          <div className="flex items-center gap-3">
            <a href="/" className="text-gray-400 hover:text-white text-sm transition-colors">View Store</a>
            <button
              onClick={handleLogout}
              className="bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <p className="text-gray-400 text-sm">Total Products</p>
            <p className="text-3xl font-bold text-white">{products.length}</p>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <p className="text-gray-400 text-sm">In Stock</p>
            <p className="text-3xl font-bold text-green-400">{products.filter((p) => p.inStock).length}</p>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <p className="text-gray-400 text-sm">Out of Stock</p>
            <p className="text-3xl font-bold text-red-400">{products.filter((p) => !p.inStock).length}</p>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <p className="text-gray-400 text-sm">On Discount</p>
            <p className="text-3xl font-bold text-yellow-400">{products.filter((p) => p.discountPrice).length}</p>
          </div>
        </div>

        {/* Add Product Button */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">Product Management</h2>
          <button
            onClick={() => {
              resetForm();
              setShowForm(true);
            }}
            className="bg-skyblue hover:bg-skyblue-dark text-white px-6 py-2 rounded-lg font-semibold transition-colors flex items-center gap-2"
          >
            <span className="text-xl">+</span> Add Product
          </button>
        </div>

        {/* Product Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-start justify-center p-4 overflow-y-auto">
            <div className="bg-gray-900 border border-skyblue/30 rounded-2xl p-6 max-w-lg w-full my-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white">
                  {editingProduct ? "✏️ Edit Product" : "➕ Add New Product"}
                </h3>
                <button onClick={resetForm} className="text-gray-400 hover:text-white text-xl">✕</button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Product Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none"
                    placeholder="e.g. Premium Cotton Shirt"
                  />
                </div>
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Article Code</label>
                  <input
                    type="text"
                    value={formData.articleCode}
                    onChange={(e) => setFormData({ ...formData, articleCode: e.target.value })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none"
                    placeholder="e.g. NLF-001"
                  />
                </div>
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none h-20 resize-none"
                    placeholder="Product description..."
                  />
                </div>
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Product Image</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={formData.imageUrl}
                      onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                      className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none text-sm"
                      placeholder="Image URL or upload"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploading}
                      className="bg-skyblue/20 hover:bg-skyblue/30 text-skyblue px-4 py-3 rounded-lg transition-colors text-sm font-semibold"
                    >
                      {uploading ? "..." : "📤 Upload"}
                    </button>
                    <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleUpload} />
                  </div>
                  {formData.imageUrl && (
                    <div className="mt-2 relative inline-block">
                      <img src={formData.imageUrl} alt="Preview" className="w-24 h-24 object-cover rounded-lg border border-gray-700" />
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gray-400 text-sm block mb-1">Price (₹) *</label>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none"
                      placeholder="999"
                    />
                  </div>
                  <div>
                    <label className="text-gray-400 text-sm block mb-1">Discount Price (₹)</label>
                    <input
                      type="number"
                      value={formData.discountPrice}
                      onChange={(e) => setFormData({ ...formData, discountPrice: e.target.value })}
                      className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none"
                      placeholder="799"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Sizes (comma separated)</label>
                  <input
                    type="text"
                    value={formData.sizes}
                    onChange={(e) => setFormData({ ...formData, sizes: e.target.value })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none"
                    placeholder="S,M,L,XL,XXL"
                  />
                </div>
                <div>
                  <label className="text-gray-400 text-sm block mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-skyblue outline-none"
                  >
                    <option value="General">General</option>
                    <option value="Shirts">Shirts</option>
                    <option value="T-Shirts">T-Shirts</option>
                    <option value="Suits">Suits</option>
                    <option value="Jeans">Jeans</option>
                    <option value="Kurta">Kurta</option>
                    <option value="Ethnic">Ethnic Wear</option>
                    <option value="Formal">Formal Wear</option>
                    <option value="Casual">Casual Wear</option>
                    <option value="Accessories">Accessories</option>
                  </select>
                </div>
                <div className="flex items-center gap-3">
                  <label className="text-gray-400 text-sm">Stock Status:</label>
                  <button
                    onClick={() => setFormData({ ...formData, inStock: !formData.inStock })}
                    className={`px-4 py-2 rounded-lg font-semibold text-sm transition-colors ${
                      formData.inStock
                        ? "bg-green-600 text-white"
                        : "bg-red-600 text-white"
                    }`}
                  >
                    {formData.inStock ? "✓ In Stock" : "✕ Out of Stock"}
                  </button>
                </div>
                <div className="flex gap-3 pt-2">
                  <button
                    onClick={handleSubmit}
                    disabled={saving}
                    className="flex-1 bg-skyblue hover:bg-skyblue-dark disabled:bg-gray-700 text-white py-3 rounded-lg font-bold transition-colors"
                  >
                    {saving ? "Saving..." : editingProduct ? "Update Product" : "Add Product"}
                  </button>
                  <button
                    onClick={resetForm}
                    className="px-6 py-3 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Products List */}
        <div className="space-y-4">
          {products.length === 0 ? (
            <div className="text-center py-16 bg-gray-900 rounded-2xl border border-gray-800">
              <p className="text-5xl mb-4">📦</p>
              <p className="text-gray-400 text-lg">No products yet</p>
              <p className="text-gray-500 text-sm mt-2">Click &quot;Add Product&quot; to get started</p>
            </div>
          ) : (
            products.map((product) => (
              <div
                key={product.id}
                className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex flex-col md:flex-row gap-4 items-start hover:border-gray-700 transition-colors"
              >
                <div className="w-full md:w-24 h-24 bg-gray-800 rounded-lg overflow-hidden shrink-0">
                  {product.imageUrl ? (
                    <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-600 text-2xl">👔</div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-white font-semibold truncate">{product.name}</h3>
                      {product.articleCode && (
                        <p className="text-skyblue text-xs">Article: {product.articleCode}</p>
                      )}
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <button
                        onClick={() => handleEdit(product)}
                        className="bg-skyblue/20 hover:bg-skyblue/30 text-skyblue px-3 py-1 rounded text-sm transition-colors"
                      >
                        ✏️ Edit
                      </button>
                      <button
                        onClick={() => handleToggleStock(product)}
                        className={`px-3 py-1 rounded text-sm transition-colors ${
                          product.inStock
                            ? "bg-green-600/20 hover:bg-green-600/30 text-green-400"
                            : "bg-red-600/20 hover:bg-red-600/30 text-red-400"
                        }`}
                      >
                        {product.inStock ? "In Stock" : "Out of Stock"}
                      </button>
                      <button
                        onClick={() => handleDelete(product.id)}
                        className="bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white px-3 py-1 rounded text-sm transition-colors"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 mt-2">
                    {product.discountPrice ? (
                      <>
                        <span className="text-skyblue font-bold">₹{product.discountPrice}</span>
                        <span className="text-gray-500 line-through text-sm">₹{product.price}</span>
                        <span className="text-red-400 text-xs font-semibold">
                          {Math.round(((product.price - product.discountPrice) / product.price) * 100)}% OFF
                        </span>
                      </>
                    ) : (
                      <span className="text-skyblue font-bold">₹{product.price}</span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {product.sizes.split(",").map((s) => (
                      <span key={s} className="bg-gray-800 text-gray-400 px-2 py-0.5 rounded text-xs">{s.trim()}</span>
                    ))}
                    {product.category && (
                      <span className="bg-skyblue/10 text-skyblue px-2 py-0.5 rounded text-xs ml-2">{product.category}</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
